import json
import psycopg2
from datetime import datetime

# Load JSON data from file with specified encoding
with open('data.json', encoding='utf-8') as f:
    data = json.load(f)

# Connect to PostgreSQL
conn = psycopg2.connect(
    dbname="dashboard_db", 
    user="postgres", 
    password="", 
    host="localhost", 
    port="5432"
)
cursor = conn.cursor()

# Convert date strings to datetime objects where applicable and handle empty strings
for item in data:
    item['end_year'] = int(item['end_year']) if item['end_year'] else None
    item['start_year'] = int(item['start_year']) if item['start_year'] else None
    item['intensity'] = int(item['intensity']) if item['intensity'] else None
    item['relevance'] = int(item['relevance']) if item['relevance'] else None
    item['likelihood'] = int(item['likelihood']) if item['likelihood'] else None
    item['added'] = datetime.strptime(item['added'], "%B, %d %Y %H:%M:%S") if item['added'] else None
    item['published'] = datetime.strptime(item['published'], "%B, %d %Y %H:%M:%S") if item['published'] else None

# Insert JSON data into the table
for item in data:
    cursor.execute("""
        INSERT INTO insights (
            end_year, intensity, sector, topic, insight, url, region, start_year, impact, added, published, country, relevance, pestle, source, title, likelihood
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
    """, (
        item['end_year'],
        item['intensity'],
        item['sector'] if item['sector'] else None,
        item['topic'] if item['topic'] else None,
        item['insight'],
        item['url'],
        item['region'] if item['region'] else None,
        item['start_year'],
        item['impact'] if item['impact'] else None,
        item['added'],
        item['published'],
        item['country'] if item['country'] else None,
        item['relevance'],
        item['pestle'] if item['pestle'] else None,
        item['source'],
        item['title'],
        item['likelihood']
    ))
conn.commit()

# Close connection
cursor.close()
conn.close()
