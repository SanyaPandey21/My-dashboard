import psycopg2

# Connect to PostgreSQL
conn = psycopg2.connect(
    dbname="dashboard_db", 
    user="postgres", 
    password="", 
    host="localhost", 
    port="5432"
)
cursor = conn.cursor()

# Create table if it does not exist
cursor.execute("""
    CREATE TABLE IF NOT EXISTS insights (
        id SERIAL PRIMARY KEY,
        end_year VARCHAR,
        intensity INT,
        sector VARCHAR,
        topic VARCHAR,
        insight VARCHAR,
        url VARCHAR,
        region VARCHAR,
        start_year VARCHAR,
        impact VARCHAR,
        added TIMESTAMP,
        published TIMESTAMP,
        country VARCHAR,
        relevance INT,
        pestle VARCHAR,
        source VARCHAR,
        title VARCHAR,
        likelihood INT
    );
""")
conn.commit()

# Close connection
cursor.close()
conn.close()
